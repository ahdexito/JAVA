package examen_ejercicio4;

import java.util.Scanner;

public class Examen_ejercicio4 
{

     public static void main(String[] args) 
     {
	  Scanner sc = new Scanner (System.in);
	  
	  // Pedimos el dato como cadena de texto.
	  System.out.println("Introduce la cantidad de euros por teclado: ");
	  String cantidadBill = sc.nextLine();
	  
	  // Convertimos el dato a tipo entero.
	  int cantidadBillEnt = Integer.parseInt(cantidadBill);
	  
	  // Creamos variables para cada tipo de billete.
	  final int BILLETES500, BILLETES200, BILLETES100, BILLETES50, BILLETES20, BILLETES10, BILLETES5;
	 
	  // Dividimos para obtener la cantidad de billetes, y realizamos módulo para saber lo que sobra.
	  BILLETES500 = cantidadBillEnt / 500;
	  cantidadBillEnt = cantidadBillEnt %500;
	  
	  BILLETES200 = cantidadBillEnt / 200;
	  cantidadBillEnt = cantidadBillEnt % 200;
	  
	  BILLETES100 = cantidadBillEnt / 100;
	  cantidadBillEnt = cantidadBillEnt % 100;
	  
	  BILLETES50 = cantidadBillEnt / 50;
	  cantidadBillEnt = cantidadBillEnt % 50;
	  
	  BILLETES20 = cantidadBillEnt / 20;
	  cantidadBillEnt = cantidadBillEnt % 20;
	  
	  BILLETES10 = cantidadBillEnt / 10;
	  cantidadBillEnt = cantidadBillEnt % 10;
	  
	  BILLETES5 = cantidadBillEnt / 5;
	  cantidadBillEnt = cantidadBillEnt % 5;
	 
	  // Imprimimos por pantalla el resultado.
	  System.out.printf("Tiene en total:\n"
			 + "\t%d billete(s) de 500.\n"
			 + "\t%d billete(s) de 200.\n"
			 + "\t%d billete(s) de 100.\n"
			 + "\t%d billete(s) de 50.\n"
			 + "\t%d billete(s) de 20.\n"
			 + "\t%d billete(s) de 10.\n"
			 + "\t%d billete(s) de 5.\n"
			 + "\tSobran %d euro(s).\n",
		  BILLETES500, BILLETES200, BILLETES100, BILLETES50, BILLETES20, BILLETES10, BILLETES5, cantidadBillEnt);
	  
     }
     
}
