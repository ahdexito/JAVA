package examen_ejercicio5;

import java.util.Scanner;

public class Examen_ejercicio5 
{

     public static void main(String[] args) 
     {
	  Scanner sc = new Scanner(System.in);
	  
	  // Solicitamos el peso de los materiales.
	  System.out.println("Introduce el peso de las vigas:");
	  float pesoVigas = sc.nextFloat();
	  
	  System.out.println("Introduce el peso de los cables:");
	  float pesoCables = sc.nextFloat();
	  
	  System.out.println("Introduce el peso del hormigón:");
	  int pesoHormigon = sc.nextInt();
	  
	  // Elevamos al cuadrado los datos introducidos.
	  pesoVigas = (float) Math.pow(pesoVigas, 2);
	  pesoCables = (float) Math.pow(pesoCables, 2);
	  pesoHormigon = (int) Math.pow(pesoHormigon, 2);
	  
	  // Realizamos la suma.
	  float totalToneladas = pesoVigas + pesoCables + pesoHormigon;
	  
	  // Realizamos el cast del total para poder mostrarlo sin decimales.
	  int totalToneEntero = (int) totalToneladas;
	  
	  // Mostramos los resultados por pantalla.
	  System.out.printf("El peso total de los materiales (con cada peso al cuadrado) es: %.3f toneladas.\n", totalToneladas);
	  System.out.printf("El peso total de los materiales (sin decimales) es: %d toneladas.\n", totalToneEntero);
	  
	  
	  
	  
     }
     
}
